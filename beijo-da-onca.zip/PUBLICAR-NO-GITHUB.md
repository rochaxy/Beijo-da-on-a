# Publicar a loja com o histórico disponível

A pasta beijo-da-onca contém os arquivos para rodar a loja. O README dessa pasta explica a instalação pelo XAMPP.

O arquivo historico-loja.bundle guarda dois commits feitos no encerramento da atividade. Eles registram duas versões preservadas durante o trabalho: o primeiro pacote funcional e a revisão que incorporou o catálogo da marca. As datas dos commits correspondem ao empacotamento.

Para publicar, extraia este ZIP e abra o terminal na pasta que contém o arquivo .bundle. Crie antes um repositório vazio no GitHub, na sua conta. Nos comandos abaixo, substitua URL_DO_REPOSITORIO pela URL HTTPS que o GitHub mostrar.

```sh
git clone -b main historico-loja.bundle loja-para-publicar
cd loja-para-publicar
git remote set-url origin URL_DO_REPOSITORIO
git push -u origin main
```

Confira no GitHub se a página mostra a pasta public, o README, database/schema.sql e os commits. Entregue o link do repositório conforme o enunciado.
